package model;

public enum VehicleType {
    ARRV,
    FIGHTER,
    HELICOPTER,
    IFV,
    TANK
}

import random
from collections import defaultdict

from model.ActionType import ActionType
from model.Game import Game
from model.Move import Move
from model.Player import Player
from model.World import World
from model.Unit import Unit
from model.VehicleType import VehicleType

def get_distance_in_turns(u1, u2, turn_count):
    u1t = Unit(0, u1.x + u1.speed_x * 2, u1.y + u1.speed_y * 2)
    u2t = Unit(0, u2.x + u2.speed_x * 2, u2.y + u2.speed_y * 2)
    return u1t.get_distance_to_unit(u2t)

class MyStrategy:
    def __init__(self):
        self.vehicles = {}
        self.facilities = {}
        self.random_initialized = False
        self.latest_facility = None
        self.spread_state = [
            (ActionType.CLEAR_AND_SELECT, VehicleType.ARRV),
            (ActionType.SCALE, VehicleType.ARRV),
            (ActionType.CLEAR_AND_SELECT, VehicleType.FIGHTER),
            (ActionType.SCALE, VehicleType.FIGHTER),
            (ActionType.CLEAR_AND_SELECT, VehicleType.HELICOPTER),
            (ActionType.SCALE, VehicleType.HELICOPTER),
            (ActionType.CLEAR_AND_SELECT, VehicleType.IFV),
            (ActionType.SCALE, VehicleType.IFV),
            (ActionType.CLEAR_AND_SELECT, VehicleType.TANK),
            (ActionType.SCALE, VehicleType.TANK)]
        self.nuke_actions = []
        self.facility_moves = []

    def init_random(self):
        if not self.random_initialized:
            self.random_initialized = True
            random.seed(self.game.random_seed)

    def update_vehicles(self):
        for v in self.world.new_vehicles:
            self.vehicles[v.id] = v
        for v in self.vehicles.values():
            v.speed_x = 0
            v.speed_y = 0
        for vu in self.world.vehicle_updates:
            if vu.id in self.vehicles:
                if vu.durability == 0:
                    del self.vehicles[vu.id]
                else:
                    self.vehicles[vu.id].speed_x = vu.x - self.vehicles[vu.id].x
                    self.vehicles[vu.id].speed_y = vu.y - self.vehicles[vu.id].y
                    self.vehicles[vu.id].update(vu)
        for f in self.world.facilities:
            self.facilities[f.id] = f


    def move(self, me: Player, world: World, game: Game, move: Move):
        self.me = me
        self.world = world
        self.game = game
        self._move = move
        self.next_facility = 0

        self.init_random()
        self.update_vehicles()

        if self.spread_state:
            self.spread()
        else:
            if world.tick_index % 10 == 0 or self.nuke_actions:
                self.find_and_destroy()
            elif world.tick_index > 70:
                self.try_to_capture_facility()

    def spread(self):
        at, vt = self.spread_state[0]
        self.spread_state = self.spread_state[1:]
        self._move.action = at
        if at == ActionType.CLEAR_AND_SELECT:
            self._move.vehicle_type = vt
            self._move.right = self.world.width
            self._move.bottom = self.world.height
        else:
            my = [v for v in self.vehicles.values() if v.player_id == self.me.id and v.type == vt]
            x_m = min(v.x for v in my)
            y_m = min(v.y for v in my)
            
            self._move.factor = 10
            self._move.x = int(x_m * 0.8)
            self._move.y = int(y_m * 0.8)

    def find_and_destroy(self):
        if self.nuke_actions:
            at, my_ready, x, y = self.nuke_actions[0]
            self.nuke_actions = self.nuke_actions[1:]
            if at == ActionType.CLEAR_AND_SELECT:
                self._move.action = at
                self._move.left = self.vehicles[my_ready].x - 1
                self._move.right = self.vehicles[my_ready].x + 1
                self._move.top = self.vehicles[my_ready].y - 1
                self._move.bottom = self.vehicles[my_ready].x + 1
            elif at == ActionType.MOVE:
                if my_ready in self.vehicles:
                    self._move.action = at
                    self._move.vehicle_id = my_ready
                    self._move.x = 0
                    self._move.y = 0
                else:
                    self.nuke_actions = []
            else:
                if my_ready in self.vehicles:
                    self._move.action = at
                    self._move.vehicle_id = my_ready
                    self._move.x = x
                    self._move.y = y
                    print("NUKE")
            return
        if self.me.remaining_nuclear_strike_cooldown_ticks > 2:
            return
        my = [v for v in self.vehicles.values() if v.player_id == self.me.id]
        enemies = [v for v in self.vehicles.values() if v.player_id != self.me.id]

        my_ready = defaultdict(list)
        enemies_available = {}
        for v in my:
            for e in enemies:
                if (v.get_distance_to_unit(e) < self.game.tactical_nuclear_strike_radius and
                        get_distance_in_turns(v, e, 2) < self.game.tactical_nuclear_strike_radius):
                    enemies_available[e.id] = 0
                    my_ready[v.id].append(e.id)
        if not enemies_available:
            return
        for e in enemies:
            for eaid in enemies_available.keys():
                if e.get_distance_to_unit(self.vehicles[eaid]) < self.game.tactical_nuclear_strike_radius:
                    cur_metric = 2 - (e.durability / e.max_durability)
                    if e.type == VehicleType.ARRV:
                        cur_metric *= 0.4
                    enemies_available[eaid] += cur_metric
            for myid in my_ready.keys():
                if e.get_distance_to_unit(self.vehicles[myid]) < self.game.tactical_nuclear_strike_radius:
                    enemies_available[eaid] -= 0.9

        enemies_available = list(reversed(sorted((v, k) for k, v in enemies_available.items())))
        enemy_to_kill = enemies_available[0][1]
        ready_cnt = len(my_ready)
        my_ready = sorted((-len(v), k) for k, v in my_ready.items() if enemy_to_kill in v)[0][1]

        if self.world.tick_index < 600:
            return

        x = self.vehicles[enemy_to_kill].x + self.vehicles[enemy_to_kill].speed_x * 2
        y = self.vehicles[enemy_to_kill].y + self.vehicles[enemy_to_kill].speed_y * 2
        self.nuke_actions = [
            (ActionType.CLEAR_AND_SELECT, my_ready, x, y),
            (ActionType.MOVE, my_ready, x, y),
            (ActionType.TACTICAL_NUCLEAR_STRIKE, my_ready, x, y)]
        self.find_and_destroy()

    def facility_window_tlbr(self, f_id):
        fleft = self.facilities[f_id].left
        ftop = self.facilities[f_id].top
        m = 1 if self.world.tick_index > 700 else 0.5 if self.world.tick_index > 400 else 0.1
        top = max(ftop - m * self.game.facility_height, 0)
        left = max(fleft - m * self.game.facility_width, 0)
        right = min(fleft + (1 + m) * self.game.facility_width, self.world.width)
        bottom = min(ftop + (1 + m) * self.game.facility_height, self.world.height)
        return top, left, bottom, right


    def facility_real_tlbr(self, f_id):
        fleft = self.facilities[f_id].left
        ftop = self.facilities[f_id].top
        return ftop, fleft, ftop + self.game.facility_height, fleft + self.game.facility_width

    def try_to_capture_facility(self):
        if not self.facilities:
            return

        if self.facility_moves:
            at, fi = self.facility_moves[0]
            self.facility_moves = self.facility_moves[1:]
            t, l, b, r = self.facility_window_tlbr(fi)
            self._move.action = at
            if at == ActionType.CLEAR_AND_SELECT:
                self._move.action = ActionType.CLEAR_AND_SELECT
                self._move.top = t
                self._move.left = l
                self._move.bottom = b
                self._move.right = r
            else:
                self._move.x = int(l + r) / 2
                self._move.y = int(t + b) / 2
                self._move.factor = 0.1
            return
        if self.world.tick_index % 7 == 0:
            desired_f_id = None
            desired_f_count = 1
            my = [v for v in self.vehicles.values() if v.player_id == self.me.id
                  and v.type != VehicleType.HELICOPTER and v.type != VehicleType.FIGHTER]
            for f_id, f in self.facilities.items():
                if f_id is self.latest_facility or f.owner_player_id == self.me.id:
                    continue
                t, l, b, r = self.facility_window_tlbr(f_id)
                rt, rl, rb, rr = self.facility_real_tlbr(f_id)
                my_kinda_here = [v for v in my if
                    (l < v.x < r) and (t < v.y < b)]
                my_inside = [v for v in my if
                    (rl < v.x < rr) and (rt < v.y < rb)]
                my_here = [v for v in my_kinda_here if not v in my_inside]
                print(my_here)
                if len(my_here) > desired_f_count:
                    desired_f_id = f_id
                    desired_f_count = len(my_here)
            if desired_f_id is not None:
                print("GOGO facilities")
                self.facility_moves = [
                    (ActionType.CLEAR_AND_SELECT, desired_f_id),
                    (ActionType.SCALE, desired_f_id)]
                #self.latest_facility = desired_f_id
                self.try_to_capture_facility()

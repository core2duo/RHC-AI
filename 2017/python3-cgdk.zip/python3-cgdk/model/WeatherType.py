from enum import IntEnum


class WeatherType(IntEnum):
    CLEAR = 0
    CLOUD = 1
    RAIN = 2

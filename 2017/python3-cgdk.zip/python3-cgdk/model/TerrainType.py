from enum import IntEnum


class TerrainType(IntEnum):
    PLAIN = 0
    SWAMP = 1
    FOREST = 2

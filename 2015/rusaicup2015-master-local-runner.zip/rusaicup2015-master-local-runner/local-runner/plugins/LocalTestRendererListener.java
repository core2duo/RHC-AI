import java.awt.*;

import model.*;

import static java.lang.StrictMath.*;

import java.nio.file.*;
import java.nio.charset.StandardCharsets;

public final class LocalTestRendererListener {
    private Graphics graphics;
    private World world;
    private Game game;

    private int canvasWidth;
    private int canvasHeight;

    private double left;
    private double top;
    private double width;
    private double height;

    private Double NextWaypointX;
    private Double NextWaypointY;
    private Double NextNextWaypointX;
    private Double NextNextWaypointY;

    public void beforeDrawScene(Graphics graphics, World world, Game game, int canvasWidth, int canvasHeight,
                                double left, double top, double width, double height) {
        updateFields(graphics, world, game, canvasWidth, canvasHeight, left, top, width, height);

        graphics.setColor(Color.BLACK);
        // drawRect(100.0D, 100.0D, 5100.0D, 5100.0D);

        /*for (Car car : world.getCars()) {
            drawCircle(car.getX(), car.getY(), hypot(car.getWidth(), car.getHeight()) / 2.0D);
        }*/
    }

    public void afterDrawScene(Graphics graphics, World world, Game game, int canvasWidth, int canvasHeight,
                               double left, double top, double width, double height) {
        updateFields(graphics, world, game, canvasWidth, canvasHeight, left, top, width, height);

        graphics.setColor(Color.GRAY);
        drawNet(world);

        graphics.setColor(Color.BLUE);
        // drawCircle(2600.0D, 2600.0D, 2400.0D);

        for (Car car : world.getCars()) {
            StringBuilder builder = new StringBuilder();
            builder.append("X: ");
            builder.append(car.getX());
            builder.append("\n");
            builder.append("Y: ");
            builder.append(car.getY());
            builder.append("\n");
            builder.append("SpeedX: ");
            builder.append(car.getSpeedX());
            builder.append("\n");
            builder.append("SpeedY: ");
            builder.append(car.getSpeedY());
            builder.append("\n");
            builder.append("Speed: ");
            builder.append(Math.sqrt(car.getSpeedY() * car.getSpeedY() + car.getSpeedX() * car.getSpeedX()));
            builder.append("\n");
            builder.append("EnginePower: ");
            builder.append(car.getEnginePower());
            builder.append("\n");
            builder.append("WheelTurn: ");
            builder.append(car.getWheelTurn());
            drawText(car.getX(), car.getY(), builder.toString());
            //fillCircle(car.getX(), car.getY(), car.getHeight() / 2.0D);
        }



        for (int[] waypoint : world.getWaypoints()) {
            graphics.setColor(Color.RED);
            drawCircle(waypoint[0] * 800.0 + 400.0, waypoint[1] * 800.0 + 400.0, 400.0);
            graphics.setColor(Color.BLUE);
            StringBuilder builder = new StringBuilder();
            builder.append("X: ");
            builder.append(waypoint[0] * 800.0 + 400.0);
            builder.append("\n");
            builder.append("Y: ");
            builder.append(waypoint[1] * 800.0 + 400.0);
            drawText(waypoint[0] * 800.0 + 400.0, waypoint[1] * 800.0 + 400.0, builder.toString());
        }
        try{
          for (String task: Files.readAllLines(Paths.get(/*"D:\\*/"/Volumes/RAMD/RenderInfoRusAICup.txt"), StandardCharsets.UTF_8)) {
              parseExternalDrawTask(task);
          }
        }
        catch(Exception e)
        {
          /* err later */
        }
        processExternalDraw();
    }

    private void drawNet(World world)
    {
        int width = (int) world.getWidth() * 800;
        int height = (int) world.getHeight() * 800;


        float alpha = 0.4f;
        Color color = new Color(0.4f, 0.4f, 0.4f, alpha);
        graphics.setColor(color);

        for(int i = 80; i <= width - 80; i+= 160)
        {
            drawLine(i, 0, i, height);
        }
        for(int j = 80; j <= height - 80; j+= 160)
        {
            drawLine(0, j, width, j);   
        }
    }

    private void parseExternalDrawTask(String task)
    {
        String[] task_parts = task.split(" ");
        if(task_parts.length < 1)
        {
          return;
        }
        switch(task_parts[0])
        {
            case "Point":
                if(task_parts.length != 3)
                  return;
                try{
                    double x = Double.parseDouble(task_parts[1].replaceAll(",", "."));
                    double y = Double.parseDouble(task_parts[2].replaceAll(",", "."));
                    drawCircle(x, y, 300);
                    drawCircle(x, y, 200);
                    drawCircle(x, y, 100);
                    StringBuilder sb = new StringBuilder();
                    sb.append(x);
                    sb.append(", ");
                    sb.append(y);
                    drawText(x, y, sb.toString());
                }
                catch(Exception e) {
                  /* err later */
                  return;
                }
                break;
            case "Text":
                if(task_parts.length < 5)
                  return;
                try{
                    double x = Double.parseDouble(task_parts[1].replaceAll(",", "."));
                    double y = Double.parseDouble(task_parts[2].replaceAll(",", "."));
                    String color = task_parts[3];
                    setStringColor(color);
                    String text = task_parts[4];
                    drawText(x, y, text);
                }
                catch(Exception e) {
                  /* err later */
                  return;
                }
                break;
            case "NextWaypoint":
                if(task_parts.length != 3)
                  return;
                try{
                    double x = Double.parseDouble(task_parts[1].replaceAll(",", "."));
                    double y = Double.parseDouble(task_parts[2].replaceAll(",", "."));
                    NextWaypointX = x;
                    NextWaypointY = y;
                    
                }
                catch(Exception e) {
                  /* err later */
                  return;
                }
                break;
            case "NextNextWaypoint":
                if(task_parts.length != 3)
                  return;
                try{
                    double x = Double.parseDouble(task_parts[1].replaceAll(",", "."));
                    double y = Double.parseDouble(task_parts[2].replaceAll(",", "."));
                    NextNextWaypointX = x;
                    NextNextWaypointY = y;
                    
                }
                catch(Exception e) {
                  /* err later */
                  return;
                }
                break;
            case "Traectory":
                try{
                    graphics.setColor(Color.BLUE);
                    for(int i = 1; i <= task_parts.length - 4; i+= 2)
                    {
                        double x = Double.parseDouble(task_parts[i].replaceAll(",", "."));
                        double y = Double.parseDouble(task_parts[i + 1].replaceAll(",", "."));
                        double x2 = Double.parseDouble(task_parts[i + 2].replaceAll(",", "."));
                        double y2 = Double.parseDouble(task_parts[i + 3].replaceAll(",", "."));
                        drawLine(x, y, x2, y2);
                    }
                }
                catch(Exception e) {
                  System.out.println(e);
                  return;
                }
                break;
            case "ColoredTraectory":
                try{
                    setStringColor(task_parts[1]);
                    for(int i = 2; i <= task_parts.length - 4; i+= 2)
                    {
                        double x = Double.parseDouble(task_parts[i].replaceAll(",", "."));
                        double y = Double.parseDouble(task_parts[i + 1].replaceAll(",", "."));
                        double x2 = Double.parseDouble(task_parts[i + 2].replaceAll(",", "."));
                        double y2 = Double.parseDouble(task_parts[i + 3].replaceAll(",", "."));
                        drawLine(x, y, x2, y2);
                    }
                }
                catch(Exception e) {
                  System.out.println(e);
                  return;
                }
                break;
            default:
                break;
        }
    }

    private void setStringColor(String color)
    {
        if(color == "BLUE")
            graphics.setColor(Color.BLUE);
        else if(color == "RED")
            graphics.setColor(Color.RED);
        else if(color == "GREEN")
            graphics.setColor(Color.GREEN);
        else if(color == "YELLOW")
            graphics.setColor(Color.YELLOW);
        else
            graphics.setColor(Color.BLACK);
    }

    private void processExternalDraw()
    {
        if(NextWaypointX == null && NextWaypointY == null)
            return;
        graphics.setColor(Color.GREEN);
        drawCircle(NextWaypointX, NextWaypointY, 400.0);
        drawCircle(NextWaypointX, NextWaypointY, 200.0);
        drawCircle(NextWaypointX, NextWaypointY, 100.0);
        if(NextNextWaypointX == null || NextNextWaypointY == null)
            return;

        graphics.setColor(Color.GRAY);
        drawCircle(NextNextWaypointX, NextNextWaypointY, 400.0);
        drawCircle(NextNextWaypointX, NextNextWaypointY, 200.0);
        drawCircle(NextNextWaypointX, NextNextWaypointY, 100.0);

        graphics.setColor(Color.GREEN);
        drawLine(NextWaypointX, NextWaypointY, NextNextWaypointX, NextNextWaypointY);
    }

    private void updateFields(Graphics graphics, World world, Game game, int canvasWidth, int canvasHeight,
                              double left, double top, double width, double height) {
        this.graphics = graphics;
        this.world = world;
        this.game = game;

        this.canvasWidth = canvasWidth;
        this.canvasHeight = canvasHeight;

        this.left = left;
        this.top = top;
        this.width = width;
        this.height = height;
    }

    private void drawLine(double x1, double y1, double x2, double y2) {
        Point2I lineBegin = toCanvasPosition(x1, y1);
        Point2I lineEnd = toCanvasPosition(x2, y2);

        graphics.drawLine(lineBegin.getX(), lineBegin.getY(), lineEnd.getX(), lineEnd.getY());
    }

    private void fillCircle(double centerX, double centerY, double radius) {
        Point2I topLeft = toCanvasPosition(centerX - radius, centerY - radius);
        Point2I size = toCanvasOffset(2.0D * radius, 2.0D * radius);

        graphics.fillOval(topLeft.getX(), topLeft.getY(), size.getX(), size.getY());
    }

    private void drawCircle(double centerX, double centerY, double radius) {
        Point2I topLeft = toCanvasPosition(centerX - radius, centerY - radius);
        Point2I size = toCanvasOffset(2.0D * radius, 2.0D * radius);

        graphics.drawOval(topLeft.getX(), topLeft.getY(), size.getX(), size.getY());
    }

    private void drawText(double centerX, double centerY, String text) {
        Font curFont = graphics.getFont();
        Font newFont = curFont.deriveFont(curFont.getSize() * 0.9F);
        graphics.setFont(newFont);

        Point2I topLeft = toCanvasPosition(centerX, centerY);
        int x = topLeft.getX();
        int y = topLeft.getY();
        for (String line : text.split("\n"))
            graphics.drawString(line, x, y += graphics.getFontMetrics().getHeight());

        graphics.setFont(curFont);
    }

    private void fillArc(double centerX, double centerY, double radius, int startAngle, int arcAngle) {
        Point2I topLeft = toCanvasPosition(centerX - radius, centerY - radius);
        Point2I size = toCanvasOffset(2.0D * radius, 2.0D * radius);

        graphics.fillArc(topLeft.getX(), topLeft.getY(), size.getX(), size.getY(), startAngle, arcAngle);
    }

    private void drawArc(double centerX, double centerY, double radius, int startAngle, int arcAngle) {
        Point2I topLeft = toCanvasPosition(centerX - radius, centerY - radius);
        Point2I size = toCanvasOffset(2.0D * radius, 2.0D * radius);

        graphics.drawArc(topLeft.getX(), topLeft.getY(), size.getX(), size.getY(), startAngle, arcAngle);
    }

    private void fillRect(double left, double top, double width, double height) {
        Point2I topLeft = toCanvasPosition(left, top);
        Point2I size = toCanvasOffset(width, height);

        graphics.fillRect(topLeft.getX(), topLeft.getY(), size.getX(), size.getY());
    }

    private void drawRect(double left, double top, double width, double height) {
        Point2I topLeft = toCanvasPosition(left, top);
        Point2I size = toCanvasOffset(width, height);

        graphics.drawRect(topLeft.getX(), topLeft.getY(), size.getX(), size.getY());
    }

    private void drawPolygon(Point2D... points) {
        int pointCount = points.length;

        for (int pointIndex = 1; pointIndex < pointCount; ++pointIndex) {
            Point2D pointA = points[pointIndex];
            Point2D pointB = points[pointIndex - 1];
            drawLine(pointA.getX(), pointA.getY(), pointB.getX(), pointB.getY());
        }

        Point2D pointA = points[0];
        Point2D pointB = points[pointCount - 1];
        drawLine(pointA.getX(), pointA.getY(), pointB.getX(), pointB.getY());
    }

    private Point2I toCanvasOffset(double x, double y) {
        return new Point2I(x * canvasWidth / width, y * canvasHeight / height);
    }

    private Point2I toCanvasPosition(double x, double y) {
        return new Point2I((x - left) * canvasWidth / width, (y - top) * canvasHeight / height);
    }

    private static final class Point2I {
        private int x;
        private int y;

        private Point2I(double x, double y) {
            this.x = toInt(round(x));
            this.y = toInt(round(y));
        }

        private Point2I(int x, int y) {
            this.x = x;
            this.y = y;
        }

        private Point2I() {
        }

        public int getX() {
            return x;
        }

        public void setX(int x) {
            this.x = x;
        }

        public int getY() {
            return y;
        }

        public void setY(int y) {
            this.y = y;
        }

        private static int toInt(double value) {
            @SuppressWarnings("NumericCastThatLosesPrecision") int intValue = (int) value;
            if (abs((double) intValue - value) < 1.0D) {
                return intValue;
            }
            throw new IllegalArgumentException("Can't convert double " + value + " to int.");
        }
    }

    private static final class Point2D {
        private double x;
        private double y;

        private Point2D(double x, double y) {
            this.x = x;
            this.y = y;
        }

        private Point2D() {
        }

        public double getX() {
            return x;
        }

        public void setX(double x) {
            this.x = x;
        }

        public double getY() {
            return y;
        }

        public void setY(double y) {
            this.y = y;
        }
    }
}

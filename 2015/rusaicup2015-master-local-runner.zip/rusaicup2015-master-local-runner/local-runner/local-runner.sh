java -jar "local-runner.jar" local-runner.properties &
